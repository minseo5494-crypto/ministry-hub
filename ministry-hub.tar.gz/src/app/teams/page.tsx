'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getCurrentUser, signOut } from '@/lib/auth';
import { getUserTeams } from '@/lib/teamOperations';
import { Users, Plus, UserPlus, LogOut, Home, Settings } from 'lucide-react';
import Link from 'next/link';

export default function TeamsPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [teams, setTeams] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const currentUser = await getCurrentUser();
      if (!currentUser) {
        router.push('/login');
        return;
      }
      setUser(currentUser);
      
      const userTeams = await getUserTeams(currentUser.id);
      setTeams(userTeams);
    } catch (error) {
      console.error('Error loading teams:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    router.push('/login');
  };

  const getRoleBadge = (role: string) => {
    const badges = {
      admin: 'bg-red-100 text-red-800',
      leader: 'bg-blue-100 text-blue-800',
      member: 'bg-gray-100 text-gray-800'
    };
    const labels = {
      admin: '관리자',
      leader: '리더',
      member: '멤버'
    };
    return (
      <span className={`px-2 py-1 text-xs rounded-full ${badges[role as keyof typeof badges]}`}>
        {labels[role as keyof typeof labels]}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 헤더 */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Users className="w-8 h-8 text-blue-600" />
              <h1 className="text-2xl font-bold">내 팀</h1>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sm text-gray-600">
                {user?.email}
              </span>
              <Link href="/">
                <button className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 flex items-center">
                  <Home className="mr-2" size={18} />
                  메인으로
                </button>
              </Link>
              <button
                onClick={handleSignOut}
                className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 flex items-center"
              >
                <LogOut className="mr-2" size={18} />
                로그아웃
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* 액션 버튼 */}
        <div className="flex gap-3 mb-8">
          <Link href="/teams/create">
            <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
              <Plus className="mr-2" size={20} />
              새 팀 만들기
            </button>
          </Link>
          <Link href="/teams/join">
            <button className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center">
              <UserPlus className="mr-2" size={20} />
              초대 코드로 참여
            </button>
          </Link>
        </div>

        {/* 팀 목록 */}
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
            <p className="mt-4 text-gray-600">팀 목록을 불러오는 중...</p>
          </div>
        ) : teams.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-8 text-center">
            <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-bold mb-2">아직 참여한 팀이 없습니다</h3>
            <p className="text-gray-600 mb-6">
              새 팀을 만들거나 초대 코드를 입력하여 팀에 참여하세요
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {teams.map((team) => (
              <Link href={`/teams/${team.id}`} key={team.id}>
                <div className="bg-white rounded-lg shadow hover:shadow-lg transition p-6 cursor-pointer">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{team.name}</h3>
                      {team.type === 'church_internal' && team.church_name && (
                        <p className="text-sm text-gray-600 mt-1">
                          🏛️ {team.church_name}
                        </p>
                      )}
                    </div>
                    {getRoleBadge(team.role)}
                  </div>
                  
                  <div className="pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-500">
                        초대 코드: <span className="font-bold">{team.invite_code}</span>
                      </span>
                      {team.role === 'admin' && (
                        <button className="text-sm text-blue-600 hover:underline">
                          <Settings className="inline w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}