'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { createTeam } from '@/lib/teamOperations';
import { Users, Copy, Check } from 'lucide-react';

export default function CreateTeamPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [teamCreated, setTeamCreated] = useState(false);
  const [inviteCode, setInviteCode] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    type: 'church_internal' as 'church_internal' | 'external',
    churchName: ''
  });

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      router.push('/login');
      return;
    }
    setUser(currentUser);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      alert('팀 이름을 입력해주세요');
      return;
    }

    if (formData.type === 'church_internal' && !formData.churchName.trim()) {
      alert('교회명을 입력해주세요');
      return;
    }

    setLoading(true);

    try {
      const team = await createTeam(
        formData.name,
        formData.type,
        formData.type === 'church_internal' ? formData.churchName : null,
        user.id
      );

      setInviteCode(team.invite_code);
      setTeamCreated(true);
      
    } catch (error: any) {
      console.error('Team creation error:', error);
      alert(error.message || '팀 생성에 실패했습니다');
    } finally {
      setLoading(false);
    }
  };

  const copyInviteCode = () => {
    navigator.clipboard.writeText(inviteCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (teamCreated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-md p-8 max-w-md w-full text-center">
          <div className="mb-6">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold mb-2">팀 생성 완료!</h2>
            <p className="text-gray-600">
              {formData.name} 팀이 생성되었습니다
            </p>
          </div>

          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-600 mb-2">초대 코드</p>
            <div className="flex items-center justify-center gap-2">
              <span className="text-3xl font-bold tracking-wider text-blue-600">
                {inviteCode}
              </span>
              <button
                onClick={copyInviteCode}
                className="p-2 text-gray-600 hover:text-gray-900 transition"
                title="복사"
              >
                {copied ? <Check size={20} /> : <Copy size={20} />}
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              팀원들에게 이 코드를 공유하세요
            </p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => router.push('/teams')}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              팀 관리로 이동
            </button>
            <button
              onClick={() => router.push('/')}
              className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
            >
              메인으로
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-md p-8">
          <div className="flex items-center gap-3 mb-6">
            <Users className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold">새 팀 만들기</h1>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">
                팀 유형 *
              </label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({
                  ...formData,
                  type: e.target.value as 'church_internal' | 'external'
                })}
                className="w-full px-3 py-2 border rounded-lg"
              >
                <option value="church_internal">교회 내부팀 (청년부, 대학부 등)</option>
                <option value="external">외부팀 (프로젝트팀, 연합팀 등)</option>
              </select>
            </div>

            {formData.type === 'church_internal' && (
              <div>
                <label className="block text-sm font-medium mb-1">
                  교회명 *
                </label>
                <input
                  type="text"
                  value={formData.churchName}
                  onChange={(e) => setFormData({
                    ...formData,
                    churchName: e.target.value
                  })}
                  placeholder="예: 사랑의교회"
                  className="w-full px-3 py-2 border rounded-lg"
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium mb-1">
                팀 이름 *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({
                  ...formData,
                  name: e.target.value
                })}
                placeholder={
                  formData.type === 'church_internal' 
                    ? "예: 청년부, 대학1부" 
                    : "예: 워십온파이어, 특별프로젝트팀"
                }
                className="w-full px-3 py-2 border rounded-lg"
              />
            </div>

            <div className="bg-blue-50 rounded-lg p-4 text-sm text-blue-800">
              💡 팀을 생성하면 6자리 초대 코드가 생성됩니다. 
              이 코드를 팀원들에게 공유하여 팀에 참여할 수 있습니다.
            </div>

            <div className="flex gap-2 pt-4">
              <button
                type="button"
                onClick={() => router.back()}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                disabled={loading}
              >
                취소
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
              >
                {loading ? '생성 중...' : '팀 만들기'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}