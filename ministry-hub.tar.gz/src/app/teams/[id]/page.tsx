'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { getTeamMembers } from '@/lib/teamOperations';
import { supabase } from '@/lib/supabase';
import { Users, Music, Plus, Settings, Home, Copy, Check } from 'lucide-react';
import Link from 'next/link';

export default function TeamDetailPage() {
  const router = useRouter();
  const params = useParams();
  const teamId = params.id as string;
  
  const [user, setUser] = useState<any>(null);
  const [team, setTeam] = useState<any>(null);
  const [members, setMembers] = useState<any[]>([]);
  const [teamSongs, setTeamSongs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [userRole, setUserRole] = useState<string>('');

  useEffect(() => {
    loadData();
  }, [teamId]);

  const loadData = async () => {
    try {
      const currentUser = await getCurrentUser();
      if (!currentUser) {
        router.push('/login');
        return;
      }
      setUser(currentUser);

      // 팀 정보 가져오기
      const { data: teamData } = await supabase
        .from('teams')
        .select('*')
        .eq('id', teamId)
        .single();

      if (!teamData) {
        router.push('/teams');
        return;
      }
      setTeam(teamData);

      // 사용자 역할 확인
      const { data: memberData } = await supabase
        .from('team_members')
        .select('role')
        .eq('team_id', teamId)
        .eq('user_id', currentUser.id)
        .single();

      if (memberData) {
        setUserRole(memberData.role);
      }

      // 팀 멤버 가져오기
      const teamMembers = await getTeamMembers(teamId);
      setMembers(teamMembers);

      // 팀 악보 가져오기
      const { data: songs, error } = await supabase
        .from('songs')
        .select('*')
        .eq('owner_type', 'team')
        .eq('owner_id', teamId)
        .order('created_at', { ascending: false });

      if (!error && songs) {
        setTeamSongs(songs);
      }

    } catch (error) {
      console.error('Error loading team data:', error);
    } finally {
      setLoading(false);
    }
  };

  const copyInviteCode = () => {
    navigator.clipboard.writeText(team.invite_code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const copyToPersonal = async (song: any) => {
    try {
      // 이미 복사했는지 확인
      const { data: existing } = await supabase
        .from('songs')
        .select('id')
        .eq('owner_type', 'personal')
        .eq('owner_id', user.id)
        .eq('source_context', `team:${teamId}`)
        .eq('song_name', song.song_name)
        .single();

      if (existing) {
        alert('이미 내 악보에 있습니다!');
        return;
      }

      // 개인 공간에 복사
      const { error } = await supabase
        .from('songs')
        .insert({
          song_name: song.song_name,
          team_name: song.team_name,
          key: song.key,
          time_signature: song.time_signature,
          tempo: song.tempo,
          bpm: song.bpm,
          theme1: song.theme1,
          theme2: song.theme2,
          lyrics: song.lyrics,
          file_url: song.file_url,
          file_type: song.file_type,
          owner_type: 'personal',
          owner_id: user.id,
          uploaded_by: user.id,
          source_context: `team:${teamId}`
        });

      if (error) throw error;

      alert('내 악보에 복사되었습니다!');
    } catch (error) {
      console.error('Copy error:', error);
      alert('복사 실패');
    }
  };

  const getRoleBadge = (role: string) => {
    const badges = {
      admin: 'bg-red-100 text-red-800',
      leader: 'bg-blue-100 text-blue-800',
      member: 'bg-gray-100 text-gray-800'
    };
    const labels = {
      admin: '관리자',
      leader: '리더',
      member: '멤버'
    };
    return (
      <span className={`px-2 py-1 text-xs rounded-full ${badges[role as keyof typeof badges]}`}>
        {labels[role as keyof typeof labels]}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 헤더 */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/teams">
                <button className="p-2 hover:bg-gray-100 rounded">
                  <Home size={20} />
                </button>
              </Link>
              <h1 className="text-2xl font-bold">{team?.name}</h1>
              {team?.type === 'church_internal' && team?.church_name && (
                <span className="text-sm text-gray-600">({team.church_name})</span>
              )}
            </div>
            <div className="flex items-center gap-3">
              {userRole === 'admin' && (
                <button className="p-2 hover:bg-gray-100 rounded">
                  <Settings size={20} />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* 팀 정보 */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-bold mb-4">팀 정보</h2>
              
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">초대 코드</p>
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-bold">{team?.invite_code}</span>
                    <button
                      onClick={copyInviteCode}
                      className="p-1 hover:bg-gray-100 rounded"
                      title="복사"
                    >
                      {copied ? <Check size={16} /> : <Copy size={16} />}
                    </button>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-gray-600 mb-2">팀원 ({members.length}명)</p>
                  <div className="space-y-2">
                    {members.map((member) => (
                      <div key={member.id} className="flex items-center justify-between">
                        <span className="text-sm">{member.users?.name || member.users?.email}</span>
                        {getRoleBadge(member.role)}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 팀 악보 목록 */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold">팀 악보</h2>
                <button 
                    onClick={() => router.push(`/teams/${teamId}/upload`)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center"
                >
                    <Plus className="mr-2" size={18} />
                    악보 추가
                </button>
              </div>

              {teamSongs.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Music className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                  <p>아직 팀 악보가 없습니다</p>
                  <p className="text-sm mt-1">첫 번째 악보를 추가해보세요!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {teamSongs.map((song) => (
                    <div key={song.id} className="border rounded-lg p-4 hover:bg-gray-50">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg">{song.song_name}</h3>
                          <div className="text-sm text-gray-600 mt-1">
                            {song.team_name && <span className="mr-3">{song.team_name}</span>}
                            {song.key && <span className="mr-3">Key: {song.key}</span>}
                            {song.tempo && <span>{song.tempo}</span>}
                          </div>
                        </div>
                        
                        <div className="flex gap-2">
                          {song.file_url && (
                            <a
                              href={song.file_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-3 py-1.5 text-sm border rounded hover:bg-gray-100"
                            >
                              악보 보기
                            </a>
                          )}
                          <button
                            onClick={() => copyToPersonal(song)}
                            className="px-3 py-1.5 text-sm bg-blue-600 text-white rounded hover:bg-blue-700"
                          >
                            내 악보에 복사
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}