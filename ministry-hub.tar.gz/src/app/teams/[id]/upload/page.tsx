'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { Upload, X, Music, Plus } from 'lucide-react';
import Link from 'next/link';

export default function TeamUploadPage() {
  const router = useRouter();
  const params = useParams();
  const teamId = params.id as string;
  
  const [user, setUser] = useState<any>(null);
  const [team, setTeam] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    song_name: '',
    team_name: '',
    key: '',
    time_signature: '',
    tempo: '',
    bpm: '',
    theme1: '',
    theme2: '',
    lyrics: ''
  });

  useEffect(() => {
    loadData();
  }, [teamId]);

  const loadData = async () => {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      router.push('/login');
      return;
    }
    setUser(currentUser);

    // 팀 정보 가져오기
    const { data: teamData } = await supabase
      .from('teams')
      .select('*')
      .eq('id', teamId)
      .single();

    if (!teamData) {
      router.push('/teams');
      return;
    }
    setTeam(teamData);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      const validTypes = ['application/pdf', 'image/jpeg', 'image/png'];
      
      if (!validTypes.includes(selectedFile.type)) {
        alert('PDF, JPG, PNG 파일만 업로드 가능합니다');
        return;
      }
      
      if (selectedFile.size > 10 * 1024 * 1024) { // 10MB
        alert('파일 크기는 10MB 이하여야 합니다');
        return;
      }
      
      setFile(selectedFile);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file || !formData.song_name) {
      alert('파일과 곡 제목은 필수입니다');
      return;
    }

    setLoading(true);

    try {
      // 1. 파일 업로드
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}_${formData.song_name}.${fileExt}`;
      const filePath = `team-${teamId}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('song-files')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // 2. Storage URL 가져오기
      const { data: urlData } = supabase.storage
        .from('song-files')
        .getPublicUrl(filePath);

      // 3. DB에 팀 악보 저장
      const { error: dbError } = await supabase
        .from('songs')
        .insert({
          song_name: formData.song_name,
          team_name: formData.team_name,
          key: formData.key || null,
          time_signature: formData.time_signature || null,
          tempo: formData.tempo || null,
          bpm: formData.bpm ? parseInt(formData.bpm) : null,
          theme1: formData.theme1 || null,
          theme2: formData.theme2 || null,
          lyrics: formData.lyrics || null,
          file_url: urlData.publicUrl,
          file_type: file.type.includes('pdf') ? 'pdf' : 'image',
          owner_type: 'team',
          owner_id: teamId,
          uploaded_by: user.id
        });

      if (dbError) throw dbError;

      // 4. 업로더의 개인 공간에 자동 복사
      await supabase
        .from('songs')
        .insert({
          song_name: formData.song_name,
          team_name: formData.team_name,
          key: formData.key || null,
          time_signature: formData.time_signature || null,
          tempo: formData.tempo || null,
          bpm: formData.bpm ? parseInt(formData.bpm) : null,
          theme1: formData.theme1 || null,
          theme2: formData.theme2 || null,
          lyrics: formData.lyrics || null,
          file_url: urlData.publicUrl,
          file_type: file.type.includes('pdf') ? 'pdf' : 'image',
          owner_type: 'personal',
          owner_id: user.id,
          uploaded_by: user.id,
          source_context: `team:${teamId}`
        });

      alert('악보가 성공적으로 추가되었습니다!');
      router.push(`/teams/${teamId}`);
      
    } catch (error) {
      console.error('Upload error:', error);
      alert('악보 업로드에 실패했습니다');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">팀 악보</h2>
            <button 
              onClick={() => router.push(`/teams/${teamId}/upload`)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center"
            >
              <Plus className="mr-2" size={18} />
              악보 추가
            </button>
          </div>

          <p className="text-sm text-gray-600 mb-6">
            {team?.name}에 새로운 악보를 추가합니다
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* 파일 업로드 */}
            <div>
              <label className="block text-sm font-medium mb-2">
                악보 파일 *
              </label>
              <div className="border-2 border-dashed rounded-lg p-6 text-center">
                {file ? (
                  <div className="flex items-center justify-center gap-2">
                    <Music size={20} />
                    <span>{file.name}</span>
                    <button
                      type="button"
                      onClick={() => setFile(null)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <X size={16} />
                    </button>
                  </div>
                ) : (
                  <>
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                    <input
                      type="file"
                      onChange={handleFileChange}
                      accept=".pdf,.jpg,.jpeg,.png"
                      className="hidden"
                      id="file-upload"
                    />
                    <label
                      htmlFor="file-upload"
                      className="cursor-pointer text-blue-600 hover:underline"
                    >
                      파일 선택 또는 드래그
                    </label>
                    <p className="text-xs text-gray-500 mt-1">
                      PDF, JPG, PNG (최대 10MB)
                    </p>
                  </>
                )}
              </div>
            </div>

            {/* 곡 정보 입력 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">
                  곡 제목 *
                </label>
                <input
                  type="text"
                  required
                  value={formData.song_name}
                  onChange={(e) => setFormData({...formData, song_name: e.target.value})}
                  className="w-full px-3 py-2 border rounded-lg"
                  placeholder="예: 주 은혜 임하소서"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  팀/아티스트
                </label>
                <input
                  type="text"
                  value={formData.team_name}
                  onChange={(e) => setFormData({...formData, team_name: e.target.value})}
                  className="w-full px-3 py-2 border rounded-lg"
                  placeholder="예: 마커스워십"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">키</label>
                <select
                  value={formData.key}
                  onChange={(e) => setFormData({...formData, key: e.target.value})}
                  className="w-full px-3 py-2 border rounded-lg"
                >
                  <option value="">선택</option>
                  {['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'].map(key => (
                    <option key={key} value={key}>{key}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">박자</label>
                <select
                  value={formData.time_signature}
                  onChange={(e) => setFormData({...formData, time_signature: e.target.value})}
                  className="w-full px-3 py-2 border rounded-lg"
                >
                  <option value="">선택</option>
                  {['4/4', '3/4', '6/8', '12/8'].map(sig => (
                    <option key={sig} value={sig}>{sig}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">템포</label>
                <select
                  value={formData.tempo}
                  onChange={(e) => setFormData({...formData, tempo: e.target.value})}
                  className="w-full px-3 py-2 border rounded-lg"
                >
                  <option value="">선택</option>
                  <option value="느림">느림</option>
                  <option value="보통">보통</option>
                  <option value="빠름">빠름</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">BPM</label>
                <input
                  type="number"
                  value={formData.bpm}
                  onChange={(e) => setFormData({...formData, bpm: e.target.value})}
                  className="w-full px-3 py-2 border rounded-lg"
                  placeholder="예: 120"
                />
              </div>
            </div>

            {/* 가사 */}
            <div>
              <label className="block text-sm font-medium mb-1">가사</label>
              <textarea
                value={formData.lyrics}
                onChange={(e) => setFormData({...formData, lyrics: e.target.value})}
                className="w-full px-3 py-2 border rounded-lg"
                rows={6}
                placeholder="가사를 입력하세요"
              />
            </div>

            {/* 제출 버튼 */}
            <div className="flex gap-2 pt-4">
              <Link href={`/teams/${teamId}`} className="flex-1">
                <button
                  type="button"
                  className="w-full px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                >
                  취소
                </button>
              </Link>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
              >
                {loading ? '업로드 중...' : '악보 추가'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}