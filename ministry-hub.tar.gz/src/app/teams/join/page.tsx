'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { joinTeam } from '@/lib/teamOperations';
import { UserPlus } from 'lucide-react';

export default function JoinTeamPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [inviteCode, setInviteCode] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      router.push('/login');
      return;
    }
    setUser(currentUser);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (inviteCode.length !== 6) {
      alert('초대 코드는 6자리여야 합니다');
      return;
    }

    setLoading(true);

    try {
      const team = await joinTeam(inviteCode.toUpperCase(), user.id);
      alert(`${team.name} 팀에 가입되었습니다!`);
      router.push('/teams');
    } catch (error: any) {
      console.error('Team join error:', error);
      alert(error.message || '팀 가입에 실패했습니다');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-md p-8 max-w-md w-full">
        <div className="flex items-center gap-3 mb-6">
          <UserPlus className="w-8 h-8 text-blue-600" />
          <h1 className="text-2xl font-bold">팀 참여하기</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">
              초대 코드 입력
            </label>
            <input
              type="text"
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
              placeholder="예: ABC123"
              maxLength={6}
              className="w-full px-4 py-3 text-center text-2xl font-bold tracking-wider border rounded-lg uppercase"
              autoFocus
            />
            <p className="text-xs text-gray-500 mt-2">
              팀 관리자로부터 받은 6자리 초대 코드를 입력하세요
            </p>
          </div>

          <div className="flex gap-2 pt-4">
            <button
              type="button"
              onClick={() => router.back()}
              className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
              disabled={loading}
            >
              취소
            </button>
            <button
              type="submit"
              disabled={loading || inviteCode.length !== 6}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
            >
              {loading ? '참여 중...' : '팀 참여'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}